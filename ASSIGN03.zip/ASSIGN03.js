import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { Button, Text, View } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';

function HomeScreen({ navigation }) {
  return (
    <View>
      <Text>Recipe Sharing App</Text>
      <Button title='Login' onPress={() => navigation.navigate("Login")} />
      <Button title='Sign Up' onPress={() => navigation.navigate("SignUp")} />
      <Button title='Profile' onPress={() => navigation.navigate("Profile")} />
    </View>
  );
}

function Login({ navigation }) {
  return (
    <View>
      <Text>
        <b>Welcome to our restaurant</b>
      </Text>
      <Text>Name</Text>
      <Text>Last Name</Text>
      <Text>Email</Text>
      <Text>Password</Text>
      <Button title='Back To Home Screen' onPress={() => navigation.goBack()} />
    </View>
  );
}

function SignUp({ navigation }) {
  return (
    <View>
      <Text>
        <b>Personal Details</b>
      </Text>
      <Text>- Name.</Text>
      <Text>- Last Name.</Text>
      <Text>- Email.</Text>
      <Text>- Password.</Text>
      <Text>- Confirm Password.</Text>
      <Button title='Back To Home Screen' onPress={() => navigation.goBack()} />
    </View>
  );
}

function Profile({ navigation }) {
  return (
    <View>
      <Text>
        <b>Name</b>
      </Text>
      <Text>Last Name</Text>
      <Text>Email</Text>
      <Text>Password</Text>
      <Text>Profile picture</Text>
      <Button title='Back To Home Screen' onPress={() => navigation.goBack()} />
    </View>
  );
}

const Stack = createStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="SignUp" component={SignUp} />
        <Stack.Screen name="Profile" component={Profile} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
